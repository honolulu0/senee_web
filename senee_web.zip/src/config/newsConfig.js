export const config1Title = "关于Senee实习生招聘启动啦"
export const config1 = "海外KOL营销/红人推广专员  5-15K<br/><br/>"+ 
"岗位职责<br/>"+
"1、开发渠道流量和海外红人资源 (Instagram、YouTube、Facebook、Tiktok等)，积累网红资源做品牌推广，"+
"产品测评和促销，维护媒介资源，制定媒介资源库，建立长期稳定合作关系；<br/>"+
"2、熟知海外不同媒体平台属性、媒体形态、用户触媒习惯等特性，总结方法论，对渠道合作效果进行整理、分析和总结，定期提交数据分析报告及合作总结；<br/><br/>"+
"3、海外社交平台（尤其Instagram，TikTok）各种玩法，对社交媒体及口碑营销有一定的认识；<br/>"+
"4、领导安排的其他工作。<br/><br/>"+

"任职要求（可招实习生和应届毕业生）<br/>"+
"1、本科以上学历英语达到正常沟通水平以及可以用英语回复邮件；<br/>"+
"2、2年及以上的工作经验，海外留学经验，有同业网红公司、MCN公司、新媒体公司，从事过网红经纪工作者、有KOL资源、会做策划PPT者优先；<br/>"+
"3、良好的沟通能力、应变能力、影响力和说服力；<br/>"+
"4、思维敏捷，有良好的团队协作能力，学习能力强，工作效率高，抗压性好；<br/>"+
"5、熟练操作office、Foxmail等办公软件。<br/><br/>"+

"福利待遇"+
"1、底薪+提成+年终奖。<br/>"+
"2、上班时间（7:00-15:30，午休1小时），单双休。<br/>"+
"3、全勤奖、节日福利、带薪年假、月度团建、五险一金。<br/><br/>"+

"工作地点<br/>"+
"广东省深圳市龙岗区雅园路万科第五园三期"

export const config2Title="Amazon版本Tiktok？Amazon Influencer打出的又一张什么牌？"
export const config2 = "<p style='font-size:20px'><span style='font-size:50px'>01</span>创新</p>"+
"<p style='font-size:18px;padding-top:40px'>随着社交媒体的崛起，特别是Ins电商闭环和TikTok电商闭环的市场机遇，传统的电商零售模式已经不能适应当前的市场需求。</p>"+
"<p style='font-size:18px;padding-top:30px;color:blue'>面对这一局势，Amazon迅速应对市场变化推出了全新的功能Amazon Inspire！</p>"+
"<p style='font-size:18px;padding-top:15px'>Inspire是一个短视频购物平台，已经整合到Amazon的应用中。</p>"+
"<p style='font-size:18px;padding-top:15px;color:blue'>它将社交媒体平台（如TikTok和Instagram）的优点与Amazon电子商务平台的便捷性和可靠性相结合。</p>"+
"<p style='font-size:18px;padding-top:15px'>通过Inspire，用户可以发现新产品，观看有趣和有益的视频，并直接从应用程序进行购买。</p>"+
"<img style='display: block;width:60%;margin:38px auto 0' src="+require("../assets/img/nimg10.png")+" /><br/>"+
"<p style='font-size:18px;padding-top:15px'>与小红书及部分社交媒体一样，Feed功能引导用户选择自己的兴趣标签，可以帮助用户在简单易用的方式中探索新的产品和观看有趣的视频。</p>"+
"<p style='font-size:18px;padding-top:15px;color:blue'>通过选择自己的兴趣，例如露营、室内植物和咖啡制作，用户可以设置自己的Shoppable Feed。</p>"+
"<p style='font-size:18px;padding-top:15px'>这种个性化的设置使得用户可以看到与自己兴趣相关的图片和视频内容。</p>"+
"<img style='display: block;margin:38px auto 0;' src="+require("../assets/img/nimg11.png")+" /><br/>"+
"<p style='font-size:20px;padding-top:15px'><span style='font-size:50px'>02</span>独特</p>"+
"<p style='font-size:18px;padding-top:40px'>对于消费者来说，Amazon Inspire提供了一个全新的体验，让他们可以通过短视频发现新的产品并直接在应用程序中进行购买。</p>"+
"<p style='font-size:18px;padding-top:30px;color:blue'>他们可以根据自己的兴趣设定喜好，从而确保他们看到的内容是相关的和有吸引力的。</p>"+
"<p style='font-size:18px;padding-top:15px'>用户可以通过观看有趣和信息丰富的短视频，与seller建立更加亲密的关系，从而更好地了解他们的产品。</p>"+
"<p style='font-size:18px;padding-top:15px'>站在seller的角度，Amazon Inspire提供了一个独特的机会来接触新的客户群并推动转化。</p>"+
"<p style='font-size:18px;padding-top:30px;color:blue'>通过利用有影响力的人生成和分享的短视频的力量，卖家可以以一种动态和吸引人的方式展示他们的产品，同时与消费者建立更私人的联系。</p>"+
"<p style='font-size:18px;padding-top:15px'>它有可能与抖音的算法相抗衡，再加上亚马逊庞大的消费者群体，在这个平台上取得成功的可能性很大。</p>"+
"<p style='font-size:18px;padding-top:30px;color:blue'>Amazon Inspire的主要优势之一是它与Amazon平台的无缝集成。</p>"+
"<p style='font-size:18px;padding-top:15px'>这种集成可以提供更流畅的购物体验，因为用户可以轻松地从观看视频过渡到购买。此外，Inspire还拥有强大的数据分析工具，帮助零售商了解他们的受众，并做出数据驱动的决策。</p>"+
"<img style='display: block;width:60%;margin:38px auto 0' src="+require("../assets/img/nimg12.png")+" /><br/>"+
"<p style='font-size:18px;padding-top:15px'>随着越来越多的消费者通过社交媒体寻找产品发现和灵感，Amazon Inspire为卖家们提供了一个独特的机会，可以利用这一趋势，吸引新的受众。</p>"+
"<p style='font-size:18px;padding-top:30px;color:blue'>Amazon 凭借其社交媒体风格的内容和电子商务功能的结合，Inspire为卖家们提供了一个强大的新工具来推动转化和增加销售额。</p>"+
"<p style='font-size:18px;padding-top:15px'> 无论你是大型零售商还是刚刚起步，现在都是时候探索Amazon Inspire并利用这个社交商务的新前沿了。</p>"+
"<p style='font-size:18px;padding-top:15px;line-height:30px;font-weight:bold'>我们团队在近10个月中，与1700位亚马逊达人生产了近13000条横版Influencer Shoppable Video，听到Amazon推出竖屏内容板块这个消息确实为之一振。今天可以先分享一下在内测中的几个板块，接下来的"+
"几个月，我将带着团队和大家一起探索这一板块的不同类目的落地效果和发展趋势。 </p>"





export const config3Title = "2023亚马逊卖家不容错过的influencer视频福利"
export const config3 = "<p  style='text-indent:2em'>亚马逊站内流量及广告价格已经处于高位，这对商家而言如何获取更多的流量现在是至关重要的，那么在精细化运营的今天如何抓住流量密码？则是大家最为关注的，自2022年开始，我们陆续发现大卖的主图视频和关联视频中出现了带有Earns Commissions标的红人关联的视频，更重要的是发现自己的listing关联视频里"+
"面有了很多竞品带有Earns Commissions标的influencer视频，被竞品薅了流量，那么这个influencer视频是如何来的？</p><br/>"+
"    <p  style='text-indent:2em'>带有Earns Commissions标的influencer视频，这就亚马逊的influencer计划，该计划是联盟计划中获取站外流量最核心的一个环节，"+
"亚马逊会挑选一些站外社媒平台关注度和互动人数较多的申请者成为亚马逊influencer。</p><br/>"+
"<p  style='text-indent:2em'>通过审核的influencer会拥有Earns Commissions蓝标认证，而在此之前是influencer蓝标认证，自2022年亚马逊对influencer开放了佣金奖励后，便更改为了Earns Commissions标，目的也是为了吸引更多站外的红人入驻成为亚马逊Influencer，在获取账号的蓝标认证的同时也会拥有像YouTube一样的视频展示页面。在Influencer页面上传产品视频，"+
"并且填入对应产品的ASIN，通过视频下方的链接购买商品，Influencer便能够得到1%-20%的销售佣金，该笔佣金由亚马逊进行支付。</p><br/>"+
"<p style='font-weight:bold'>Influencer视频制作优势&商家权益</p></br>"+
"1、专业视频制作能力：封面制作、拍摄手法、卖点引导；</br>"+
"2、多场景的展示产品使用场景，静态、动态，室内、户外；</br>"+
"3、垂直类红人对卖点深刻理解和表达，引导消费者的购物情绪，提升转换；</br>"+
"4、自动关联主图视频位置，丰富视频内容；</br>"+
"5、自动关联关联视频位置，专业的视频封面制作吸引点击；</br>"+
"6、自动关联竞品关联视频位置，蹭流量，用专业的封面和内容能力形成转换；</br>"+
"7、红人站内带货页面会像youtube一样永久留存形成长尾效应。</br>"+
"备注：据已掌握influencer视频数据分析，可有效提升销售转换3%以上。</br>"+
"对于亚马逊卖家而言，Amazon Influencer视频是花少量的钱来摊平站内高额的广告成本，进而达到提"+
"升站内销售转换率，通过视频关联获取更多站内流量，同时低成本合作站外获取更多站外流量，进而提升商品销量。</br>"+
"<p style='font-weight:bold'>【下方有Influencer相关页面的图片展示】</p></br>"+
"<img style='display: block' src="+require("../assets/img/nimg4.png")+" /><br/>"+
"<img style='display: block' src="+require("../assets/img/nimg5.png")+" /><br/>"+
"<img style='display: block' src="+require("../assets/img/nimg6.png")+" /><br/>"+
"<img style='display: block' src="+require("../assets/img/nimg7.png")+" /><br/>"+
"<img style='display: block' src="+require("../assets/img/nimg8.png")+" /><br/>"+
"<img style='display: block' src="+require("../assets/img/nimg9.png")+" />"
