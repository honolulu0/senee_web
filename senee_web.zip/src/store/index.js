import { createStore } from 'vuex';
const store = createStore({
    state: {
        title: '渐进式JavaScript 框架',
    },
    getters: {},
    actions: {},
    mutations: {

    },
    modules: {}
})

export default store;