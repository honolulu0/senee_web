<template>

  <router-view class="router"></router-view>
</template>
<script>
import { defineComponent, computed } from 'vue';
import { useStore } from 'vuex';
export default defineComponent({
  setup() {
    const store = useStore();
    return {
      title: computed(() => store.state.title)
    };
  }
});
</script>
