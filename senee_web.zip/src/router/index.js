import { createRouter, createWebHashHistory } from 'vue-router';
// import store from '../store/index'
const Index = () =>
  import(/* webpackChunkName: "index" */ '../views/index.vue');
const News = () => import(/* webpackChunkName: "news" */ '../views/news.vue');
const Job = () => import(/* webpackChunkName: "job" */ '../views/job.vue');
const About = () =>
  import(/* webpackChunkName: "about" */ '../views/about.vue');
const Detail = () =>
  import(/* webpackChunkName: "detail" */ '../views/detail.vue');
  const privacy = ()=> import(/* webpackChunkName: "detail" */ '../views/privacy.vue');
  const service = ()=> import(/* webpackChunkName: "detail" */ '../views/service.vue');
const hash = createWebHashHistory();
const router = createRouter({
  history: hash,
  routes: [
    {
      path: '/',
      name: 'index',
      component: Index,
      meta: {
        keepAlive: false // 是否缓存组件
      }
    },
    {
      path: '/news',
      name: 'news',
      component: News,
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/job',
      name: 'job',
      component: Job,
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/about',
      name: 'about',
      component: About,
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/detail',
      name: 'detail',
      component: Detail,
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/privacy',
      name: 'privacy',
      component: privacy,
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/service',
      name: 'service',
      component: service,
      meta: {
        keepAlive: false
      }
    }
  ]
});

export default router;
