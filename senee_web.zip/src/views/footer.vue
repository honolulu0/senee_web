<template>
  <footer>
    <div class="cont">
      <div class="mobile">
        <img src="../assets/img/qrg.png" class="qrcode" />
        <h2>关注公众号</h2>
        <p>微信扫一扫，回复客服，即刻了解更多Senee资讯</p>
         <img src="../assets/img/qrv.png" class="qrcode" />
        <h2>关注视频号</h2>
        <p>微信扫一扫，回复客服，即刻了解更多Senee案例</p>
        <img
          src="../assets/img/logo.png"
          srcset="../assets/img/logo.png 1x, ../assets/img/logo@2x.png 2x"
          class="logo"
        />
        <h3>最专业的社交电商全案服务商</h3>
        <div class="mid-link">
          <strong>公司网址</strong>
          <router-link to="/news">最新资讯</router-link>
          <router-link to="/about">关于我们</router-link>
          <router-link to="/job">工作机会</router-link>
        </div>
        <div class="mid-link">
          <strong>法律信息</strong>
          <a href="/#/privacy" target="_blank">隐私政策</a>
          <a href="/#/service" target="_blank">服务条款</a>
        </div>
        <h4>©2022-SENEE科技有限公司版权所有<br /><a style="color:#fff" href="https://beian.miit.gov.cn/" target="_blank">琼ICP备20001897号-4</a></h4>
      </div>

      <div class="no-mobile">
        <div class="left">
          <img
            src="../assets/img/logo2.png"
            srcset="../assets/img/logo2.png 1x, ../assets/img/logo2@2x.png 2x"
          />
          <h2>最专业的社交电商全案服务商</h2>
          <h3>©2022-SENEE科技有限公司版权所有<br /><a style="color:#fff" href="https://beian.miit.gov.cn/" target="_blank">琼ICP备20001897号-4</a></h3>
          <div class="link">
            <a href="/#/privacy" target="_blank">隐私政策</a>
            <div class="line"></div>
            <a href="/#/service" target="_blank">服务条款</a>
          </div>
        </div>
        <div class="mid">
          <router-link to="/news">最新资讯</router-link>
          <router-link to="/about">关于我们</router-link>
          <router-link to="/job">工作机会</router-link>
        </div>
        <div class="right">
          <h2>关注公众号</h2>
          <img src="../assets/img/qrg.png" />
          <p>微信扫一扫，回复客服<br />即刻了解更多Senee资讯</p>
        </div>
        <div class="right">
          <h2>关注视频号</h2>
          <img src="../assets/img/qrv.png" />
          <p>微信扫一扫，回复客服<br />即刻了解更多Senee案例</p>
        </div>
      </div>
    </div>
  </footer>
</template>
