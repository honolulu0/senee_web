<template>
  <div class="news">
    <section class="sub__banner">
      <TopBar />
      <img
        src="../assets/img/news/news.jpg"
        srcset="
          ../assets/img/news/news.jpg    1x,
          ../assets/img/news/news@2x.jpg 2x
        "
        alt=""
      />
      <h1>新闻中心</h1>
      <h2>
       Senee公司动态以及跨境社交电商赛道的最新资讯
      </h2>
    </section>
    <div class="sub__cont">
      <div class="bread">
        <router-link to="/">首页</router-link>&nbsp;/&nbsp;新闻中心
      </div>
      <ul class="news__list">
        <li>
          <a href="/#/detail?id=1">关于Senee实习生招聘启动啦</a
          ><span>2023-02-06 16:00</span>
        </li>
         <li>
          <a href="/#/detail?id=2">Amazon版本Tiktok？Amazon Influencer打出的又一张什么牌？</a
          ><span>2023-02-16 16:00</span>
        </li>
       <!-- <li>
          <a href="/#/detail?id=3">2023亚马逊卖家不容错过的influencer视频福利</a
          ><span>2023-02-06 16:00</span>
        </li> -->
      </ul>
    </div>
    <Footer />
  </div>
</template>
<script>
import { defineComponent, ref, onMounted } from 'vue';
import TopBar from './nav.vue';
import Footer from './footer.vue';
export default defineComponent({
  name: 'news',
  components: { TopBar, Footer },
  setup() {
    // const store = useStore();
    onMounted(() => {
      console.log('mounted!');
    });
    return {
      // token: computed(() => store.state.token),
      // user: computed(() => store.state.user)
    };
  }
});
</script>
<style lang="scss" scoped>
@import '../style/news.scss';
</style>
