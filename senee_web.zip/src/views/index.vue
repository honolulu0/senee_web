<template>
  <div class="index-wrap">
    <div class="index-wrap__banner">
      <vue3VideoPlay
      class="index-wrap__video"
        v-bind="options"
        poster="https://diy-assets.msstatic.com/mrfangge/SENEE/banner.png"
      />
      <TopBar />
      <h1>最专业的社交电商全案服务商</h1>
      <h2>海量全球网红+专属营销定制方案，帮助您的产品获得可见的市场提升</h2>
      <div class="index-wrap__scroll">
        <i></i>
        <p>滚动探索更多</p>
      </div>
    </div>
    <div class="index-wrap__right_qr_main">
      <div class="right_qr_box">
        <h4>关注公众号</h4>
        <img src="../assets/img/qrg.png" />
        <p>微信扫一扫,回复客服 <br/>立刻了解更多Senee咨询</p>
      </div>
      <div class="right_qr_box">
          <h4>关注视频号</h4>
        <img src="../assets/img/qrv.png" />
        <p>微信扫一扫,回复客服 <br/>立刻了解更多Senee咨询</p>
      </div>
    </div>
    <!-- 我们的优势 start -->
    <div class="index-wrap__col index-wrap__col1">
      <img
        src="../assets/img/index/title2.png"
        v-animate-onscroll="'animated fadeInUp'"
        class="index-wrap__col1title"
      />
      <ul class="index-wrap__col1banner">
        <li v-animate-onscroll="'animated fadeInUp'">
          <img
            src="../assets/img/index/indeximg1.jpg"
            srcset="
              ../assets/img/index/indeximg1.jpg    1x,
              ../assets/img/index/indeximg1@2x.jpg 2x
            "
          />
          <div class="index-wrap__col1desc">
            <h3>海量网红</h3>
            <p>
              覆盖全球不同语系；详细的分类标签<br />
              丰富的成交和反馈数据参考
            </p>
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <img
            src="../assets/img/index/indeximg2.jpg"
            srcset="
              ../assets/img/index/indeximg2.jpg    1x,
              ../assets/img/index/indeximg2@2x.jpg 2x
            "
          />
          <div class="index-wrap__col1desc">
            <h3>专业团队</h3>
            <p>
              覆盖全球不同语系；详细的分类标签<br />
              丰富的成交和反馈数据参考
            </p>
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <img
            src="../assets/img/index/indeximg3.jpg"
            srcset="
              ../assets/img/index/indeximg3.jpg    1x,
              ../assets/img/index/indeximg3@2x.jpg 2x
            "
          />
          <div class="index-wrap__col1desc">
            <h3>效果付费</h3>
            <p>
              覆盖全球不同语系；详细的分类标签<br />
              丰富的成交和反馈数据参考
            </p>
          </div>
        </li>
      </ul>
    </div>
    <!-- 我们的优势 end -->
    <!-- 全球合作案例 start -->
    <div class="index-wrap__col index-wrap__col2">
      <img
        src="../assets/img/index/title3.png"
        v-animate-onscroll="'animated fadeInUp'"
        class="index-wrap__col2title"
      />
      <section class="index-wrap__tabwrap">
        <nav v-animate-onscroll="'animated fadeInUp'">
          <ul>
            <li @click="setTabCur(0)" :class="tabIndex == 0 ? 'current' : ''">
              <img src="../assets/img/index/logo.png" alt="Tiktok" />
              <p>Tiktok</p>
            </li>
            <li @click="setTabCur(1)" :class="tabIndex == 1 ? 'current' : ''">
              <img src="../assets/img/index/logo-1.png" alt="" />
              <p>Amz</p>
            </li>
            <li @click="setTabCur(2)" :class="tabIndex == 2 ? 'current' : ''">
              <img src="../assets/img/index/logo-2.png" alt="" />
              <p>YouTube</p>
            </li>
            <li @click="setTabCur(3)" :class="tabIndex == 3 ? 'current' : ''">
              <img src="../assets/img/index/logo-3.png" alt="" />
              <p>Ins</p>
            </li>
          </ul>
          <div class="index-wrap__tabline">
            <div
              class="index-wrap__tabline--on"
              :style="{ transform: `translateX(${tabInfo[tabIndex]})` }"
            ></div>
          </div>
        </nav>
          
        <div
          class="index-wrap__tabcont animated fadeInUp"
          v-for="(item, index) in col2tabcont"
          :key="index"
          v-show="index == tabIndex"
          v-animate-onscroll="'animated fadeInUp'"
        >
          <div
            class="index-wrap__col2contwrap"
            :style="{ transform: `translate(-${col2curIndex * 1172}px,0)` }"
          >
            <div
              class="index-wrap__col2cont"
              v-for="(item2, index2) in item.tabcont"
              :key="index2"
            >
              <div :class="{'index-wrap__col2contimg':!item2.isH,'index-wrap__col2contimg_isH':item2.isH}"
              :style="{'background-image':(item2.bgimg?'url('+item2.bgimg+')' : '#000')}">
                <!-- :style="{'background':(item2.isH ? '#000':'')}"  -->
                <!-- <img class="index-wrap__bgimg" v-if="item2.bgimg" :src="item2.bgimg" /> -->
                <video :poster="item2.img"   controls v-if="item2.video && isvideoShow" :src="item2.video"></video>
                <img v-else  :src="item2.img" alt="" /><em
                  class="index-wrap__col2tag"
                  >{{ item2.tag }}</em
                >
              </div>
              <div :class="{'index-wrap__col2contdetail':!item2.isH,'index-wrap__col2contdetail_isH':item2.isH}">
                <h2>{{ item2.title }}</h2>
                <p>
                  {{ item2.intro }}
                </p>
                <h3>{{ item2.title2 }}</h3>
                <p>{{ item2.intro2 }}</p>

                <ul :class="{'index-wrap__col2contbot':!item2.isH,'index-wrap__col2contbot_isH':item2.isH}" v-if="item2.bot.length > 0">
                  <li v-for="(item3, index3) in item2.bot" :key="index3">
                    <div class="index-wrap__col2botnum">
                      {{ item3.percent }}
                    </div>
                    <div class="index-wrap__col2botintro">{{ item3.desc }}</div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div  :class="{'index-wrap__pagenav':!col2tabcont[tabIndex].tabcont[col2curIndex]['isH'],'index-wrap__pagenav_isH':col2tabcont[tabIndex].tabcont[col2curIndex]['isH']}">
            案例 {{ col2curIndex + 1 }} / {{ item.tabcont.length }}
            <div class="index-wrap__pagenavbtns">
              <div
                :class="
                  'index-wrap__pagenavbtns--prev' +
                  (col2curIndex != 0 ? ' active' : '')
                "
                @click="prevBtn"
              ></div>
              <div
                :class="
                  'index-wrap__pagenavbtns--next' +
                  (col2curIndex != item.tabcont.length - 1 ? ' active' : '')
                "
                @click="nextBtn(item.tabcont.length)"
              ></div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <!-- 全球合作案例 end -->
    <!-- 全球影响者推荐 start -->
    <div class="index-wrap__col index-wrap__col3">
      <img
        src="../assets/img/index/title4.png"
        v-animate-onscroll="'animated fadeInUp'"
        class="index-wrap__col3title"
      />
      <section
        class="index-wrap__list index-wrap__list--list1"
        v-animate-onscroll="'showin'"
      >
        <div
          class="index-wrap__col3banner"
          v-for="(item, index) in col3list1"
          :key="index"
        >
          <em>{{ item.tag }}</em>
          <img :src="item.banner" :alt="item.title" />
          <div
            class="index-wrap__col3detail"
            :style="{
              backgroundColor: `rgba(${
                col3listcolor[Math.floor(Math.random() * col3listcolor.length)]
              },.9)`
            }"
          >
            <h2>{{ item.title }}</h2>
            <p>{{ item.desc }}</p>
            <p v-if="item.intro1 || item.intro2" class="bot">
              <span>{{ item.intro1 }}</span
              >{{ item.intro2 }}
            </p>
          </div>
        </div>
      </section>
      <section
        class="index-wrap__list index-wrap__list--list2"
        v-animate-onscroll="'showin'"
      >
        <div
          class="index-wrap__col3banner"
          v-for="(item, index) in col3list2"
          :key="index"
        >
          <em>{{ item.tag }}</em>
          <img :src="item.banner" :alt="item.title" />
          <div
            class="index-wrap__col3detail"
            :style="{
              backgroundColor: `rgba(${
                col3listcolor[Math.floor(Math.random() * col3listcolor.length)]
              },.7)`
            }"
          >
            <h2>{{ item.title }}</h2>
            <p>{{ item.desc }}</p>
            <p v-if="item.intro1 || item.intro2" class="bot">
              <span>{{ item.intro1 }}</span
              >{{ item.intro2 }}
            </p>
          </div>
        </div>
      </section>
      
    </div>
    <!-- 全球影响着推荐 end -->
    <!-- 核心服务数据 start  -->
    <div class="index-wrap__col index-wrap__col4">
      <img
        src="../assets/img/index/title5.png"
        v-animate-onscroll="'animated fadeInUp'"
        class="index-wrap__col4title"
      />
      <ul class="index-wrap__col4banner">
        <li v-animate-onscroll="'animated fadeInUp'">
          <strong>2000+</strong><em>网红数量</em>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <strong>99%</strong><em>客户满意度</em>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <strong>1300+</strong><em>服务品牌（量）</em>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <strong>70%</strong><em>平均产品销售提升（率）</em>
        </li>
      </ul>
    </div>
    <!-- 核心服务数据 end  -->
    <!-- 用户在说什么 start -->
    <div class="index-wrap__col index-wrap__col5">
      <i class="quo1"></i>
      <i class="quo2"></i>
      <img
        src="../assets/img/index/title6.png"
        v-animate-onscroll="'animated fadeInUp'"
        class="index-wrap__col5title"
      />
      <div class="index-wrap__col5slide">
        <div
          class="index-wrap__col5slidewrap"
          :style="{ transform: `translateX(-${1200 * slideIndex}px)` }"
        >
          <div
            class="index-wrap__col5item"
            v-for="(item, index) in col4list"
            :key="index"
            v-animate-onscroll="'animated fadeInUp'"
          >
            <div class="index-wrap__col5user">
              <img :src="item.avatar" :alt="item.nick" />
              <div class="index-wrap__col5userdetail">
                <p>{{ item.nick }}</p>
                <blockquote>{{ item.desc }}</blockquote>
              </div>
            </div>
            <div class="index-wrap__col5comment">
              {{ item.comment }}
            </div>
          </div>
        </div>
      </div>
      <div class="index-wrap__col5nav" v-animate-onscroll="'animated fadeInUp'">
        <div
          :class="`index-wrap__col5dot${slideIndex == index ? ' active' : ''}`"
          v-for="(item, index) in col4nav"
          :key="index"
          @click="setCurSlide(index)"
        ></div>
      </div>
    </div>
    <!-- 用户在说什么 end -->
    <!-- 企业品牌信赖 start -->
    <div class="index-wrap__col index-wrap__col6">
      <img
        src="../assets/img/index/title7.png"
        v-animate-onscroll="'animated fadeInUp'"
        class="index-wrap__col6title"
      />
      <ul>
         <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l1.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l2.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l3.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
                src="../assets/img/l4.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
               src="../assets/img/l5.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l6.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l7.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l8.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l9.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l10.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="../assets/img/l11.png"
              alt=""
            />
          </div>
        </li>
        <!-- <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="https://diy-assets.msstatic.com/mrfangge/test5.png"
              alt=""
            />
          </div>
        </li>
        <li v-animate-onscroll="'animated fadeIn'">
          <div class="index-wrap__logo">
            <img
              src="https://diy-assets.msstatic.com/mrfangge/test5.png"
              alt=""
            />
          </div>
        </li> -->
      </ul>
    </div>
    <!-- 企业品牌信赖 end -->
    <Footer />
  </div>
</template>
<script>
import { defineComponent, ref, onMounted, computed, reactive } from 'vue';
import TopBar from './nav.vue';
import Footer from './footer.vue';
import tiktokv1 from "../assets/video/tiktokv1.mp4"
import tiktokv2 from "../assets/video/tiktokv2.mp4"
import Ins1 from "../assets/video/Ins1.mp4"
import amz1 from "../assets/video/amz1.mp4"
import amz2 from "../assets/video/amz2.mp4"
import ytb1 from "../assets/video/ytb1.mp4"
import ytb2 from "../assets/video/ytb2.mp4"

export default defineComponent({
  components: { TopBar, Footer },
  name: 'index',
  setup() {
    const options = reactive({
      width: '1920px', //播放器高度
      height: '1080px', //播放器高度
      title: '', //视频名称
      src: 'https://diy-assets.msstatic.com/mrfangge/SENEE/bg.mp4', //视频源
      muted: true, //静音
      webFullScreen: false,
      autoPlay: true, //自动播放
      loop: true, //循环播放
      control: false, //是否显示控制
    });
    const isvideoShow = ref(true)
    const tabIndex = ref(0);
    const slideIndex = ref(0);
    const tabInfo = ref(['-305%', '-133%', '38%', '206%']);
  const col2tabcont = ref([
      {
        tabcont: [
          {
            title: '品牌：Temu',
            video: tiktokv1,
            img: "",
            bgimg:"",
            tag: '宠物家具',
            intro:
              ' 通过创新的营销策略、高质量的宣传材料、精细的用户调研和反馈，帮助平台展示卖点和提高性价比，提高APP下载率及拉新效率，为平台的快速发展提供强有力的支持。',
            title2: '服务策略',
            intro2: '提供社交媒体推广服务，为平台背书和宣传。我们将根据平台的特点和用户需求，制定符合平台形象和风格的社交媒体推广方案。通过推广，可以提高平台的知名度和用户关注度，从而增加APP下载和用户注册。',
            bot: [
              {
                percent: '37%',
                desc: 'Temu广告点击率提升'
              },
              {
                percent: '7413',
                desc: 'App下载量提升'
              },
              {
                percent: '410k',
                desc: 'Tiktok播放量提升'
              }
            ]
          },
          {
           title: '品牌：Temu',
            video: tiktokv2,
            img: "",
             bgimg:"",
            tag: '健康家具',
            intro:
              ' 通过创新的营销策略、高质量的宣传材料、精细的用户调研和反馈，帮助平台展示卖点和提高性价比，提高APP下载率及拉新效率，为平台的快速发展提供强有力的支持。',
            title2: '服务策略',
            intro2: '提供社交媒体推广服务，为平台背书和宣传。我们将根据平台的特点和用户需求，制定符合平台形象和风格的社交媒体推广方案。通过推广，可以提高平台的知名度和用户关注度，从而增加APP下载和用户注册。',
            bot: [
              {
                percent: '37%',
                desc: 'Temu广告点击率提升'
              },
              {
                percent: '7413',
                desc: 'App下载量提升'
              },
              {
                percent: '410k',
                desc: 'Tiktok播放量提升'
              }
            ]
          }
        ]
      },
      {
        tabcont: [
           {
            title: '品牌：TCL',
            isH:true,
            video: amz1,
            img: "",
             bgimg:require("../assets/video/m1.png"),
            tag: '数码科技',
            // intro:
            //   ' 用户视角为产品卖点背书，动态展示4K短焦激光电视优势，演示使用场景。',
            title2: '服务策略',
            intro2: '用户视角为产品卖点背书，动态展示卖点，对冲差评，提高页面转化率。',
            bot: [
              {
                percent: '700%',
                desc: '竞品用户访问量提升'
              },
              {
                percent: '5%',
                desc: '亚马逊销量提升'
              },
              {
                percent: '20k',
                desc: '曝光量提升'
              }
            ]
          },
          {
            title: '品牌：Paris Rhône',
            isH:true,
            video: amz2,
            img: "",
             bgimg:require("../assets/video/m2.png"),
            tag: '数码科技',
            // intro:
            //   ' 用户视角为产品卖点背书，动态展示4K短焦激光电视优势，演示使用场景。',
            title2: '服务策略',
            intro2: '用户视角为产品卖点背书，动态展示4K短焦激光电视优势，演示使用场景。',
            bot: [
              {
                percent: '500%',
                desc: '竞品用户访问量提升'
              },
              {
                percent: '23%',
                desc: '亚马逊销量提升'
              },
              {
                percent: '37k',
                desc: '曝光量提升'
              }
            ]
          },
        ]
      },
      {
        tabcont: [
          {
            title: '品牌：Noorio',
            img: "",
            bgimg:require("../assets/video/m3.png"),
            tag: '数码科技',
             isH:true,
            video: ytb1,
            // intro:
            //   ' 品牌刚上新一款新品，需要一个8分钟左右的产品使用教程和效果视频，以展示在独立站和电商平台的商品详情页，以及自有社媒账号。',
            title2: '服务策略',
            intro2: '1.产品使用教程视频制作：我们提供8分钟左右的产品使用教程和效果视频制作，包括产品介绍、使用方法、使用效果展示等，确保客户能够更加深入地了解产品的特点和使用方法。此外，我们会提供独特的创意和设计，以确保视频在独立站、电商平台的商品详情页和自有社媒账号上吸引更多目标客户的关注。2.退货率降低策略：我们将通过分析客户的购物习惯、产品的特点以及销售环节中可能出现的问题，提供退货率降低的解决方案。撮合细节表达能力强的达人制作动态说明书，解决退货问题。',
            bot: [
              {
                percent: '90k',
                desc: 'Youtube播放量提升'
              },
              {
                percent: '5%',
                desc: '页面转化率提升'
              },
              {
                percent: '8%',
                desc: '退货率降低'
              }
            ]
          },
          {
            title: '品牌：Noorio',
            img: require("../assets/img/ytb2.png"),
            bgimg:require("../assets/video/m4.png"),
            tag: '时尚美妆',
            isH:true,
            video: ytb2,
            // intro:
            //   ' 品牌刚上新一款新品，需要一个8分钟左右的产品使用教程和效果视频，以展示在独立站和电商平台的商品详情页，以及自有社媒账号。',
            title2: '服务策略',
            intro2: '1.产品使用教程视频制作：我们提供8分钟左右的产品使用教程和效果视频制作，包括产品介绍、使用方法、使用效果展示等，确保客户能够更加深入地了解产品的特点和使用方法。此外，我们会提供独特的创意和设计，以确保视频在独立站、电商平台的商品详情页和自有社媒账号上吸引更多目标客户的关注。2.退货率降低策略：我们将通过分析客户的购物习惯、产品的特点以及销售环节中可能出现的问题，提供退货率降低的解决方案。撮合细节表达能力强的达人制作动态说明书，解决退货问题。',
            bot: [
              {
                percent: '90k',
                desc: 'Youtube播放量提升'
              },
              {
                percent: '5%',
                desc: '页面转化率提升'
              },
              {
                percent: '8%',
                desc: '退货率降低'
              }
            ]
          },
        ]
      },
      {
        tabcont: [
          {
            title: '品牌：Temu',
            video: Ins1,
            img: "",
            bgimg:"",
            tag: '时尚美妆',
            intro:
              '',
            title2: '服务策略',
            intro2: '致力于为Temu Influencer板块的推广寻找5000个达人。我们的服务策略包括以下几个方面：精选达人：我们会根据客户需求和产品特点，精选符合条件的达人，确保他们的粉丝群体能够对产品产生强烈的共鸣。定制方案：我们会为每位达人制定个性化的推广方案，确保推广效果最大化。我们会结合达人的特点和粉丝的需求，定制适合的推广内容和方式。精准投放：我们会通过大数据分析和精准投放，将达人的推广内容和品牌理念精准传达给目标用户，提高推广效果。实时监测：我们会实时监测推广效果，通过数据分析和用户反馈，及时调整推广策略，确保推广效果最佳。',
            bot: [
              {
                percent: '',
                desc: ''
              },
              {
                percent: '',
                desc: ''
              },
              {
                percent: '',
                desc: ''
              }
            ]
          },
        
        ]
      }
    ]);
    const col2curIndex = ref(0);
    const col3listcolor = [
      '255, 68, 51',
      '17,217,217',
      '245,65,83',
      '69,148,255',
      '17,17,33'
    ];
    const col3list1 = ref([
      {
        banner:require("../assets/img/index/image.png"),
        title: 'kaja_macho',
        tag: '美妆服装',
        desc: '时尚博主，颜值高身材好，非常会摆拍！可以去室外拍摄服装，视频无解说配BGM。',
        intro1: '粉丝: 370万',
        intro2: '成功案例: 5例'
      },
      {
   banner:require("../assets/img/index/image1.png"),
        title: 'auntieamandalee_',
        tag: '美妆服装',
        desc: '高颜值服装博主，户外拍摄，很专业，无讲解视配BGM，衣服上身，表现力强，视频观看效果好！',
        intro1: '粉丝: 470万',
        intro2: '成功案例: 6例'
      },
      {
       banner:require("../assets/img/index/image2.png"),
        title: 'janine_delaney',
        tag: '美妆服装',
        desc: '高颜值数码博主，爱好3C数码产品，兴趣爱好强烈，拍摄讲解细致，有很强的摄影能力和镜头感。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      },
      {
        banner:require("../assets/img/index/image3.png"),
        title: 'Not Enough Nelsons',
        tag: '美妆服装',
        desc: '家里游泳池大House，讲解和拍摄视频很细腻，有孩子，猫狗双全。视频质量高，十分推荐！',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image4.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '美妆服装',
        desc: '亚裔美女红人，美妆，服装等视频讲解全面。爱好潜水滑雪，有两只宠物狗。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image5.png"),
        title: 'janine_delaney',
        tag: '美妆服装',
        desc: '白人女性，有个2岁的孩子，可拍室外，解说详细。主做时尚，家居，电子产品，厨房类目。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      },
      {
        banner:require("../assets/img/index/image6.png"),
        title: 'Not Enough Nelsons',
        tag: '美妆服装',
        desc: '白人女性，审美好，会运镜，拍摄质量高。主家庭产品，其次电子产品。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image7.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '美妆服装',
        desc: '白人女性，可拍室外，解说详细，拍摄经验丰富。主做母婴，家居，电子产品，厨房类目。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image8.png"),
        title: 'janine_delaney',
        tag: '美妆服装',
        desc: '美女博主，视频高清，拍摄画面和谐整洁。推荐美妆，家居，户外，宠物猫相关产品。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      },
      {
        banner:require("../assets/img/index/image9.png"),
        title: 'Not Enough Nelsons',
        tag: '数码科技',
        desc: '主要介绍电子产品（无人机）其次家装工具，用品有剪辑有封面，组装能力强，视频质量高。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image10.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '数码科技',
        desc: '科技博主，拍摄高清，背景专业。擅长骑行类产品，滑板，电动滑板车，电脑周边，遥控车等。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image11.png"),
        title: 'janine_delaney',
        tag: '数码科技',
        desc: '主要拍摄电器，小家电，其次是狗狗用品。热爱手机壳手机膜，3c配件。讲解细致，拍摄有一定技巧。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      },
      {
        banner:require("../assets/img/index/image12.png"),
        title: 'Not Enough Nelsons',
        tag: '数码科技',
        desc: '科技博主，专业直播间背景，解说详细，漏脸拍摄。推荐科技电子，家电类产品。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image13.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '数码科技',
        desc: '帅气科技博主，专业背景灯光布置，视频质量高。有车，有狗，还能拍户外产品！',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image14.png"),
        title: 'janine_delaney',
        tag: '数码科技',
        desc: '美女宝妈，有一岁的男孩，有专业背景可以直播，安装能力很强，拍摄产品类型广泛。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      },
      {
        banner:require("../assets/img/index/image15.png"),
        title: 'Not Enough Nelsons',
        tag: '数码科技',
        desc: '科技博主，视频质量极高，专业拍摄手法和剪辑配音。拍摄设备齐全，产品细节展示到位，可当主图视频。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image16.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '数码科技',
        desc: '早期亚马逊红人，拍摄品类广泛，视频讲解详细，大麦经常合作的对象，十分推荐。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image17.png"),
        title: '数码科技',
        tag: '健身',
        desc: '华裔科技博主，经常做对比视频，讲解专业且详细，视频质量高，时长感人，超级推荐。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      }
    ]);
    const col3list2 = ref([
      {
        banner:require("../assets/img/index/image18.png"),
        title: '911Studios - Shopping, Gadgets & Tech',
        tag: '工具家居',
        desc: '热爱旅游，有大房子，大院子，泳池。户外为主，其他就是家居用品和玩具。边演示边讲解，视频质量高。',
        intro1: '16.3万',
        intro2: '成功案例: 50例'
      },
      {
        banner:require("../assets/img/index/image19.png"),
        title: 'Lo Knows Tech',
        tag: '工具家居',
        desc: '户外博主，家里有大院子，有房车卡车，爱好钓鱼。可以拍户外，工具类产品，视频高清，讲解详细。',
        intro1: '品台: 亚马逊',
        intro2: '成功案例: 140例'
      },
      {
       banner:require("../assets/img/index/image20.png"),
        title: 'janine_delaney',
        tag: '工具家居',
        desc: '帅气生活类博主，爱健身，有狗人士！拍摄品类广泛，厨房，家居，健身，户外都可以！',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 104例'
      },
      {
        banner:require("../assets/img/index/image21.png"),
        title: 'Not Enough Nelsons',
        tag: '工具家居',
        desc: '拍摄品类广泛，几乎不挑产品。有泳池，有狗子，还可以拍摄户外场景。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image22.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '工具家居',
        desc: '拍摄品类广泛，有户外院子，讲解详细。喜欢的产品会发到油管站外，数据很好！',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image23.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '工具家居',
        desc: '有自己的剪辑风格，边展示边讲解。主要做电器，宠物用品，可以拍户外产品。有只猫。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 20例'
      },{
       banner:require("../assets/img/index/image24.png"),
        title: 'janine_delaney',
        tag: '工具家居',
        desc: '视频专业，测评产品详细，适合厨房类，电子科技类产品，以及户外产品，家里有大草坪！',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 14例'
      },
      {
        banner:require("../assets/img/index/image25.png"),
        title: 'Not Enough Nelsons',
        tag: '工具家居',
        desc: '汽车博主油管粉丝8w+；父子搭档，儿子长得比较帅，视频质量高，拍摄品类广泛。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 60例'
      },
      {
       banner:require("../assets/img/index/image26.png"),
        title: 'janine_delaney',
        tag: '厨电家电',
        desc: '主要做刀具厨房类产品。视频有剪辑，视频高清，适合展示类产品。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 40例'
      },
      {
        banner:require("../assets/img/index/image27.png"),
        title: 'Not Enough Nelsons',
        tag: '厨电家电',
        desc: '可以拍户外，爱健身，涉及品类广泛，漏脸解说，有个奔驰车，视频质量高！',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 28例'
      },
      {
       banner:require("../assets/img/index/image28.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '厨电家电',
        desc: '一个男孩的妈妈，以玩具为主，部分食物，家庭工具，乐器。镜头感好，讲解有活力，视频质量不错！',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },{
       banner:require("../assets/img/index/image29.png"),
        title: 'janine_delaney',
        tag: '厨电家电',
        desc: '一对白人兄弟拍以户外为主。有电竞房，热爱电子产品，遥控玩具。有木屋，树林，小型木材加工坊，可以拍室外，爱好钓鱼。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      },
      {
        banner:require("../assets/img/index/image30.png"),
        title: 'Not Enough Nelsons',
        tag: '厨电家电',
        desc: '白人男性，主要拍摄厨房和食品相关产品，高清露脸，讲解细致。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image31.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '厨电家电',
        desc: '工具类博主，家里有农场，拖拉机，房车，卡车，船。爱好打猎，钓鱼。安装能力超强，视频讲解详细。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },{
       banner:require("../assets/img/index/image32.png"),
        title: 'janine_delaney',
        tag: '厨电家电',
        desc: '夫妻账号，有狗子，主要拍摄家居家电，工具等产品，动手能力强，产品讲解详细。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 4例'
      },
      {
        banner:require("../assets/img/index/image33.png"),
        title: 'Not Enough Nelsons',
        tag: '厨电家电',
        desc: '职业是亚马逊工程师，专业讲解。家里俩孩子都可以出境，室外环境也非常好。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 2例'
      },
      {
       banner:require("../assets/img/index/image34.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '厨电家电',
        desc: '户外骑行博主，专业介绍电动自行车，滑板车，户外有无人机拍摄，视频质量很高。其他电子产品也能拍，拍摄品类广泛。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 2例'
      },{
       banner:require("../assets/img/index/image35.png"),
        title: 'janine_delaney',
        tag: '运动健身',
        desc: '夫妻都可以出境。有两个女儿；家里装修不错；以厨房用具为主；部分电子产品和汽车用品；可以户外拍摄。院子能放下帐篷。',
        intro1: '粉丝: 280万',
        intro2: '成功案例: 34例'
      },
      {
        banner:require("../assets/img/index/image36.png"),
        title: 'Not Enough Nelsons',
        tag: '运动健身',
        desc: '拍摄产品广，主要针对家庭用品拍摄，讲解详细。有车  有船，喜欢出海钓鱼。',
        intro1: '粉丝: 184万',
        intro2: '成功案例: 22例'
      },
      {
       banner:require("../assets/img/index/image37.png"),
        title: 'LA FAMILIA LATORRE',
        tag: '运动健身',
        desc: '体育老师，可以拍各种运动健身器材；有孩子，猫狗双全，可以拍玩具，宠物类产品；视频风格欢快，无解说，有字幕和插图。',
        intro1: '粉丝: 94万',
        intro2: '成功案例: 20例'
      }
      // {
      //   banner:
      //     'https://diy-assets.msstatic.com/mrfangge/SENEE/assets/test2-9.png',
      //   title: 'MIKO',
      //   tag: '电子产品、开箱检测',
      //   desc: '擅长时尚造型展示、服装穿搭、个人生活，适合美妆产品、服装产品、个护产品，家居产品等推广',
      //   intro1: '粉丝: 4.5w',
      //   intro2: '成功案例: 1256例'
      // }
    ]);
   const col4list = ref([
      {
        avatar:
          require('../assets/img/user1.png'),
        nick: '爱回家',
        desc: '家居收纳',
        comment:
          '公司新产品需要有性价比的视频素材，在国内拍摄的成本比较高，不够本土化，Amazon Influencer几十美金就解决了我的需求，真棒！'
      },
      {
        avatar:
          require('../assets/img/user2.png'),
        nick: '数码达人',
        desc: '3C数码',
        comment:
          '我们自己联系KOL的时候，交付时效经常没有办法保证，被KOL忽悠，感谢有你们，让我认识到专业的服务商的谈判能力更强，价格持平的情况下交付有保障！'
      },
      {
        avatar:
          require('../assets/img/user3.png'),
        nick: '基拉大和',
        desc: '玩具',
        comment:
          '对我们小卖家太友好了，不像有些服务商高攀不起 哈哈哈哈哈哈哈哈。。。'
      },
      {
        avatar:
           require('../assets/img/user4.png'),
        nick: '百科小豆豆',
        desc: '家电',
        comment:
          '我们这种中大件在布局KOL的时候总是不知道如何下手，每次营销动作的ROI都是付的，和贵公司合作也学习到了非常多，专业又热情。'
      },
      {
        avatar:
           require('../assets/img/user5.png'),
        nick: '一念红尘',
        desc: '清洁设备',
        comment:
          '服务团队专业  资源更专业 交付超出我的预期 KOL价格相对合理，并不像市场那样不透明。'
      },
       {
        avatar:
           require('../assets/img/user6.png'),
        nick: '白月光',
        desc: '香薰产品',
        comment:
          '靠谱天花板！！！YYDS！'
      }
    ]);

    let col4nav = computed(() => {
      const len = col4list.value.length;
      return Math.floor(len / 2) + (len % 2);
    });

    onMounted(() => {
      const style = document.styleSheets[0];
      const list1len = col3list1.value.length;
      const list2len = col3list2.value.length;
      const ismobile = window.outerWidth <= 1090;
      const baseWidth = ismobile ? 260 : 400;
      const baseMargin = ismobile ? 12 : 30;
      style.insertRule(
        `@keyframes moveSlideshow {0% { transform: translateX(0%);}100% {transform: translateX(-${
          baseWidth * list1len +
          baseMargin * (list1len - 1) -
          baseWidth * (ismobile ? 1 : 3) -
          baseMargin * (ismobile ? 0 : 4) -
          baseWidth / 2
        }px);}}`
      );
      style.insertRule(
        `@keyframes moveSlideshow2 {0% { transform: translateX(0%);}100% {transform: translateX(-${
          baseWidth * list2len +
          baseMargin * (list2len - 1) -
          baseWidth * (ismobile ? 1 : 3) -
          baseMargin * (ismobile ? 0 : 4) -
          baseWidth / 2
        }px);}}`
      );
    });

    const setTabCur = (eq) => {
      tabIndex.value = eq;
      col2curIndex.value = 0;
        isvideoShow.value = false
      setTimeout(()=>{
        isvideoShow.value = true
      },50)
    };
    const nextBtn = (len) => {
      isvideoShow.value = false
      setTimeout(()=>{
        isvideoShow.value = true
      },50)
      if (col2curIndex.value == len - 1) return;
      col2curIndex.value += 1;
    };
    const prevBtn = () => {
      isvideoShow.value = false
      setTimeout(()=>{
        isvideoShow.value = true
      },50)
      if (col2curIndex.value == 0) return;
      col2curIndex.value -= 1;
    };
    const setCurSlide = (eq) => {
      slideIndex.value = eq;
    };

    return {
      tabInfo,
      tabIndex,
      col2tabcont,
      col2curIndex,
      col3list1,
      col3list2,
      col3listcolor,
      col4list,
      col4nav,
      slideIndex,
      options,
      setTabCur,
      nextBtn,
      prevBtn,
      setCurSlide,
      isvideoShow
    };
  }
});
</script>
<style lang="scss" scoped>
@import '../style/index.scss';
</style>
