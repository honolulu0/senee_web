<template>
  <div class="about">
    <section class="sub__banner">
      <TopBar />
      <img
        src="../assets/img/about/about.jpg"
        srcset="
          ../assets/img/about/about.jpg    1x,
          ../assets/img/about/about@2x.jpg 2x
        "
      />
      <h1>关于我们</h1>
      <h2>
        专注于UGC内容5年，赋能品牌5000+，完成UGC内容30000+。<br/>落户于深圳，立志于UGC内容生产的全球化，专业化，平台化。
      </h2>
      <router-link to="/job" class="banner-btn">加入我们</router-link>
    </section>
    <div class="sub__cont">
      <div class="bread">
        <router-link to="/">首页</router-link>&nbsp;/&nbsp;关于我们
      </div>
      <div class="about__banner">
        <img
          src="../assets/img/about/aboutimg1.jpg"
          srcset="
            ../assets/img/about/aboutimg1.jpg    1x,
            ../assets/img/about/aboutimg1@2x.jpg 2x
          "
          v-animate-onscroll="'animated slideInLeft'"
        />
        <div
          class="about__bannerintro"
          v-animate-onscroll="'animated slideInRight'"
        >
          <i class="num1"></i>
          <h2>我们的工作</h2>
          <hr />
          <p>成为全球品牌的创作中心</p>
          <p>文案优化</p>
          <p>图片制作</p>
          <p>视频生产</p>
        </div>
      </div>
      <div class="about__banner about__banner--right">
        <div
          class="about__bannerintro"
          v-animate-onscroll="'animated slideInLeft'"
        >
          <i class="num2"></i>
          <h2>我们的愿景</h2>
          <hr />
          <p>助力中国品牌出海</p>
          <p>致力于中国好货分享世界</p>
          <p>赋能精细化运营</p>
          <p>提高Listing转化率</p>
        </div>
        <img
          src="../assets/img/about/aboutimg2.jpg"
          srcset="
            ../assets/img/about/aboutimg2.jpg    1x,
            ../assets/img/about/aboutimg2@2x.jpg 2x
          "
          v-animate-onscroll="'animated slideInRight'"
        />
      </div>
      <div class="about__banner">
        <img
          src="../assets/img/about/aboutimg3.jpg"
          srcset="
            ../assets/img/about/aboutimg3.jpg    1x,
            ../assets/img/about/aboutimg3@2x.jpg 2x
          "
          v-animate-onscroll="'animated slideInLeft'"
        />
        <div
          class="about__bannerintro"
          v-animate-onscroll="'animated slideInRight'"
        >
          <i class="num3"></i>
          <h2>我们的价值观</h2>
          <hr />
          <p>客户第一</p>
          <p>始终创业</p>
          <p>专注热情</p>
          <p>坚韧勇敢</p>
        </div>
      </div>
      <img
        src="../assets/img/about/title.png"
        v-animate-onscroll="'animated fadeInUp'"
        class="about__title"
      />
    </div>

    <div class="about__bannerwrap">
      <div class="about__bannerbox">
        <img
          src="../assets/img/about/aboutimg4.jpg"
          srcset="
            ../assets/img/about/aboutimg4.jpg    1x,
            ../assets/img/about/aboutimg4@2x.jpg 2x
          "
          v-animate-onscroll="'animated fadeIn'"
          class="about__banner1"
        /><img
          src="../assets/img/about/aboutimg5.jpg"
          srcset="
            ../assets/img/about/aboutimg5.jpg    1x,
            ../assets/img/about/aboutimg5@2x.jpg 2x
          "
          v-animate-onscroll="'animated fadeIn'"
          class="about__banner2"
        /><img
          src="../assets/img/about/aboutimg6.jpg"
          srcset="
            ../assets/img/about/aboutimg6.jpg    1x,
            ../assets/img/about/aboutimg6@2x.jpg 2x
          "
          v-animate-onscroll="'animated fadeIn'"
          class="about__banner3"
        /><img
          src="../assets/img/about/aboutimg7.jpg"
          srcset="
            ../assets/img/about/aboutimg7.jpg    1x,
            ../assets/img/about/aboutimg7@2x.jpg 2x
          "
          v-animate-onscroll="'animated fadeIn'"
          class="about__banner4"
        /><img
          src="../assets/img/about/aboutimg8.jpg"
          srcset="
            ../assets/img/about/aboutimg8.jpg    1x,
            ../assets/img/about/aboutimg8@2x.jpg 2x
          "
          v-animate-onscroll="'animated fadeIn'"
          class="about__banner5"
        />
      </div>
    </div>
    <img
      src="../assets/img/about/title2.png"
      v-animate-onscroll="'animated fadeInUp'"
      class="about__title2"
    />
    <div class="sub__cont">
      <ol class="about__team">
        <li v-animate-onscroll="'animated fadeInUp'">
          <img src="../assets/img/about/1p.png" alt="" />
          <p>张环斌</p>
          <blockquote>
            专注于红人营销，因为专一所以专业。<br/>因为专业，所以更精。
          </blockquote>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <img src="../assets/img/about/2p.png" alt="" />
          <p>Henry</p>
          <blockquote>
            市场部负责人  深耕跨境电商领域，<br/>
            对跨境电商服务有自己独到的见解，<br/>
            始终秉持着真诚，专业得态度服务每一个客户。

          </blockquote>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <img src="../assets/img/about/3p.png" alt="" />
          <p>徐炎</p>
          <blockquote>
            曾就职于美国因赛特国际投资有限公司担任中国区负责人<br/>
拥有多年进出口贸易和海外市场营销工作经验
          </blockquote>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <img src="../assets/img/about/4p.png" alt="" />
          <p>冯理</p>
          <blockquote>
            马赛商学院工商管理硕士，曾就职于腾讯、<br/>
            虎牙等一线互联网公司，拥有有多个千万级日<br/>
            活项目的管理经验。主要负责公司平台、数据业务板块和综合管理。
          </blockquote>
        </li>
        <!-- <li v-animate-onscroll="'animated fadeInUp'">
          <img src="../assets/img/about/5p.png" alt="" />
          <p>左杰</p>
          <blockquote>
            我是David，专注于内容营销。多年的行业<br/>
            经验为您的企业提供量身定制的内容策略，<br/>
            通过各种渠道创造高质量的内容助您的品牌在市场竞争中脱颖而出。
  
          </blockquote>
        </li>
        <li v-animate-onscroll="'animated fadeInUp'">
          <img src="../assets/img/about/6p.png" alt="" />
          <p>Cray</p>
          <blockquote>
           4年亚马逊服务商工作经验。内容营销top1，<br/>
           视频方案小作文选手，说话好听又好用。<br/>
           影响者视频找我做方案，cary助你在类目carry！
          </blockquote>
        </li> -->
        <li v-animate-onscroll="'animated fadeInUp'">
          <img src="../assets/img/about/7p.png" alt="" />
          <p>CC</p>
          <blockquote>
             我是cici，刚进入行跨境行业，善于沟通，<br/>
             热爱市场营销工作，有责任心。有自己独特<br/>
             的想法是我最大的优点,能在跨境行业为大家贡献一份力量！

          </blockquote>
        </li>
      </ol>
    </div>
    <Footer />
  </div>
</template>
<script>
import { defineComponent, ref, onMounted, computed } from 'vue';
// import { useStore } from 'vuex';
import TopBar from './nav.vue';
import Footer from './footer.vue';
export default defineComponent({
  name: 'about',
  components: { TopBar, Footer },
  setup() {
    // const store = useStore();

    onMounted(() => {
      console.log('mounted!');
    });
    return {
      // token: computed(() => store.state.token),
      // user: computed(() => store.state.user)
    };
  }
});
</script>
<style lang="scss" scoped>
@import '../style/about.scss';
</style>
