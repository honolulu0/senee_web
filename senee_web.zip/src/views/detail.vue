<template>
  <div class="newsdetail">
    <TopBar />
    <div class="newsdetail__cont">
      <div class="news__bread">
        <router-link to="/">首页</router-link>&nbsp;/&nbsp;新闻中心
      </div>
      <article>
        
        <h1>{{configTitle}}</h1>
        <div class="newsdetail__date" ></div>
        <p v-html="configsHtml"></p>
       
      </article>
    </div>
    <Footer />
  </div>
</template>
<script>
import {config1,config1Title,config2,config2Title,config3,config3Title} from '../config/newsConfig'
import { defineComponent, ref, onMounted } from 'vue';
import TopBar from './nav.vue';
import Footer from './footer.vue';
import {useRoute} from 'vue-router'
export default defineComponent({
  name: 'news',
  components: { TopBar, Footer },
  setup() {
    const route = useRoute()
    const query = route.query
    console.log(query)
    // const store = useStore();
    let configsHtml = config1
    let configTitle = config1Title
    if(query.id == "1"){
      configsHtml = config1
      configTitle = config1Title
    }else if (query.id == "2"){
      configsHtml = config2
      configTitle = config2Title
    }else if(query.id == "3"){
      configsHtml = config3
      configTitle = config3Title
    }
    
    onMounted(() => {
      console.log('mounted!');
    });
    return {
      configsHtml,
      configTitle
      // token: computed(() => store.state.token),
      // user: computed(() => store.state.user)
    };
  }
});
</script>
<style lang="scss" scoped>
@import '../style/news.scss';
</style>
