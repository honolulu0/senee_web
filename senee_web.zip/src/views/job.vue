<template>
  <div class="job" :data-pop="showJob">
    <section class="sub__banner">
      <TopBar />
      <img
        src="../assets/img/job/job.jpg"
        srcset="../assets/img/job/job.jpg 1x, ../assets/img/job/job@2x.jpg 2x"
      />
      <h1>工作机会</h1>
      <h2>
        我们视员工为 senee 的真正主人。因此，我们提供对员<br />工友好的股权计划
        (RSU)、有竞争力的薪酬、绩效奖金和退休计划
      </h2>
    </section>
    <div class="sub__cont">
      <div class="bread">
        <router-link to="/">首页</router-link>&nbsp;/&nbsp;工作机会
      </div>
      <nav class="job__tab">
        <ul>
          <li
            v-for="(item, index) in jobsTab"
            :key="index"
            :class="jobsIndex == index ? 'current' : ''"
            @click="jobsIndex = index"
          >
            {{ item }}
          </li>
        </ul>
      </nav>
    </div>
    <div class="job__tabline">
      <div class="sub__cont">
        <div
          class="job__tabline--on"
          :style="{
            width: lineWidth + 'px',
            transform: `translateX(${lineWidth * jobsIndex}px)`
          }"
        ></div>
      </div>
    </div>
    <ul class="job__list">
      <li
        v-for="(item, index) in jobsList[jobsIndex]"
        :key="index"
        @click="showJobDetail(item)"
      >
        <div class="job__detail">
          <h2>{{ item.title }}</h2>
          <div class="job__info">
            <span>{{ item.loc }}</span
            ><span class="line"></span><span>{{ item.date }}</span>
          </div>
          <div class="mobile">
            <span v-for="(item, index) in item.job" :key="index">
              {{ index + 1 }}、{{ item }}
            </span>
          </div>
        </div>
        <a class="job__btn">职位详情</a>
      </li>
    </ul>
    <Footer />
    <div class="job__pop animated fadeIn" v-if="showJob && jobDetail.title">
      <div class="job__overlay" @click="hideJobDetail"></div>
      <section class="job__popcont" @click.stop="hideJobDetail">
        <h3>{{ jobDetail.title }}</h3>
        <h4>
          {{ jobDetail.loc }}
          <div class="line"></div>
          {{ jobDetail.date }}
        </h4>
        <h5>岗位职责：</h5>
        <p v-for="(item, index) in jobDetail.job" :key="index">
          {{ index + 1 }}、{{ item }}
        </p>
        <h5>任职要求：</h5>
        <p v-for="(item, index) in jobDetail.require" :key="index">
          {{ index + 1 }}、{{ item }}
        </p>
        <div class="job__link">投递邮箱：hr@senee.com.cn</div>
        <a class="job__btn2" href="mailto:xxxx@xxx.com">申请职位</a>
      </section>
    </div>
  </div>
</template>
<script>
import { defineComponent, ref, onMounted, computed } from 'vue';
import TopBar from './nav.vue';
import Footer from './footer.vue';
export default defineComponent({
  name: 'job',
  components: { TopBar, Footer },
  setup() {
    // const store = useStore();
    const jobsTab = ref(['产品、研发', '市场、运营', '行政、后勤']);
    const jobsIndex = ref(0);
    const jobsList = ref([
      [{
        title: '产品经理',
        loc: '深圳市',
        date: '2022-12-09',
        job: [
          '负责公司平台产品的整体设计和市场推广',
          '以提升平台客户数量和业务流程效率为目的，持续优化转化率、订单量等核心指标',
          '对数据敏感，有较强的数据分析能力，能够通过数据发现问题，分析问题，并提出解决方案'
        ],
        require: [
          '熟练使用Axure、墨刀、Figma等设计工具',
          '3年以上工作经验，有B端、电商行业经验者优先',
          '本科以上学历'
        ]
      },
      {
        title: '后端开发工程师',
        loc: '深圳市',
        date: '2022-12-09',
        job: [
          '负责公司平台产品后端功能开发',
          '统招大学本科及以上学历，计算机相关专业，3～5年工作经验',
          '有电商、平台类项目经验，熟悉大规模、高并发系统架构设计，有大型项目调优经历，熟悉云端项目的部署和维护',
        ],
        require: [
          '掌握Linux下C/C++/Go/Java等任意一门开发语言',
          '有较强的系统问题分析经验和能力，能够解决复杂的系统问题',
          '具备数据系统的规划设计及调优能力，熟悉常见关系数据库和非关系数据库，熟悉分布式文件系统和上层应用，有相关开发经验者优先',
          '具有系统性能分析及优化经验者优先',
          '开源社区活跃贡献者优先'
        ]
      }
      ],
      [
        {
        title: '英语运营',
        loc: '深圳市',
        date: '2022-12-09',
        job: [
          '负责公司网红资源维护、信息更新、流程跟进',
          '专科及以上学历，留学经验优先，良好的英语读写及口语能力优先',
        ],
        require: [
          '熟悉各类办公、社媒软件使用',
          '工作认真细致，有耐心，富有团队合作精神，欢迎应届毕业生，无经验可培训上岗',
        ]
      }
      ],
      [
        {
        title: '行政（后勤方向）',
        loc: '深圳市',
        date: '2022-12-09',
        job: [
          '负责公司行政内务（会议、接待、保洁、资产管理）',
          '协助管理账目相关表格制作、审批，编制现金、银行存款记账；',
          '财务、会计及相关专业，大专及以上学历，有相关工作经验优先；'
        ],
        require: [
          '熟练使用财务软件，Office办公软件',
          '诚实守信，为人正直',
        ]
      },
      {
        title: '行政（人资方向）',
        loc: '深圳市',
        date: '2022-12-09',
        job: [
          '负责公司网红资源维护、信息更新、流程跟进；',
          '专科及以上学历，留学经验优先，良好的英语读写及口语能力优先；',
        ],
        require: [
          '熟悉各类办公、社媒软件使用',
          '工作认真细致，有耐心，富有团队合作精神，欢迎应届毕业生，无经验可培训上岗'
        ]
      }
      ]
    ]);
    const showJob = ref(false);
    const jobDetail = ref({});
    const showJobDetail = (item) => {
      console.log('item: ', item);
      jobDetail.value = item;
      showJob.value = true;
    };
    const hideJobDetail = () => {
      jobDetail.value = {};
      showJob.value = false;
    };
    return {
      jobsTab,
      jobsIndex,
      lineWidth: computed(() => Math.floor(1172 / jobsTab.value.length)),
      jobsList,
      showJob,
      jobDetail,
      showJobDetail,
      hideJobDetail
    };
  }
});
</script>
<style lang="scss" scoped>
@import '../style/job.scss';
</style>
