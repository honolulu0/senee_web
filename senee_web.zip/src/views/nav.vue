<template>
  <nav class="top-bar" :class="navbgShow ? 'fixed' : ''">
    <router-link to="/"><i class="logo">SENEE</i></router-link>
    <div class="nav-icon" :data-show="mobileShowNav" @click="toggleShowNav"><i></i><i></i><i></i></div>
    <div class="nav-info"  :data-show="mobileShowNav">
      <div class="nav-list">
        <router-link to="/about">关于我们</router-link>
        <router-link to="/news">新闻中心</router-link>
        <router-link to="/job">工作机会</router-link>
      </div>
      <a href="mailto:xxxx@xxxx.com" class="nav-btn">联系我们</a>
    </div>
  </nav>
</template>
<script>
import { defineComponent, ref, onMounted } from 'vue';
export default defineComponent({
  name: 'TopBar',
  setup() {
    const mobileShowNav = ref(false);
    const navbgShow = ref(false);
    const toggleShowNav = () => {
      mobileShowNav.value = !mobileShowNav.value;
    };
    onMounted(() => {
      window.addEventListener('scroll', scrollTop, true);
      console.log('mounted!');
    });
    const scrollTop = () => {
      // 当前滚动条位置
      const scrollTop =
        document.documentElement.scrollTop || document.body.scrollTop;
      scrollTop > 80 ? (navbgShow.value = true) : (navbgShow.value = false);
      // // 可视区域
      // scrollData.client = document.documentElement.clientHeight || document.body.clientHeight;
      // // 滚动条总高度
      // scrollData.allHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
      // console.log(scrollData);
    };
    return {
      navbgShow,
      mobileShowNav,
      toggleShowNav
    };
  }
});
</script>
