import { createApp } from 'vue';
import App from './App.vue';
import VueAnimateOnScroll from 'vue3-animate-onscroll';
import router from './router/index.js';
import './style/global.scss';
import store from './store/index.js';
import filters from './filters/index';
import vue3videoPlay from 'vue3-video-play' // 引入组件
import 'vue3-video-play/dist/style.css' // 引入css
console.log('process.env', process.env);
// 开发测试环境显示console
if (process.env.VUE_APP_SHOWCONSOLE === 'true') {
  let Vconsole = require('../node_modules/vconsole/dist/vconsole.min');
  new Vconsole();
}
const app = createApp(App);
app.use(vue3videoPlay)
app.use(VueAnimateOnScroll);
app.config.globalProperties.$filters = {
  ...filters
};

app.use(router).use(store).mount('#app');
